package com.library.management.service;

import com.library.management.dto.BookCreateDto;
import com.library.management.dto.BookDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface BookService {
    Page<BookDto> getAllBooks(Pageable pageable);
    Page<BookDto> searchBooks(String query, Pageable pageable);
    BookDto getBookById(Long id);
    BookDto createBook(BookCreateDto dto);
    BookDto updateBook(Long id, BookCreateDto dto);
    void softDeleteBook(Long id);
}
