import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface IssueRequest {
  bookId: number;
  memberId: number;
}

export interface IssueResponse {
  id: number;
  bookId: number;
  bookTitle: string;
  memberId: number;
  memberName: string;
  issuedAt: string;
  dueDate: string;
  returnedAt: string | null;
  status: string;
}

@Injectable({ providedIn: 'root' })
export class IssueService {
  private apiUrl = `${environment.apiUrl}/issues`;

  constructor(private http: HttpClient) {}

  issueBook(data: IssueRequest): Observable<IssueResponse> {
    return this.http.post<IssueResponse>(`${this.apiUrl}/issue`, data);
  }

  returnBook(issueId: number): Observable<IssueResponse> {
    return this.http.post<IssueResponse>(`${this.apiUrl}/return/${issueId}`, {});
  }

  getActiveIssues(): Observable<IssueResponse[]> {
    return this.http.get<IssueResponse[]>(`${this.apiUrl}/active`);
  }

  getMemberHistory(memberId: number): Observable<IssueResponse[]> {
    return this.http.get<IssueResponse[]>(`${this.apiUrl}/history/member/${memberId}`);
  }

  getBookHistory(bookId: number): Observable<IssueResponse[]> {
    return this.http.get<IssueResponse[]>(`${this.apiUrl}/history/book/${bookId}`);
  }
}
