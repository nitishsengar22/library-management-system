package com.library.management.repository;

import com.library.management.entity.IssueRecord;
import com.library.management.entity.IssueStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IssueRecordRepository extends JpaRepository<IssueRecord, Long> {
    boolean existsByBookIdAndMemberIdAndStatus(Long bookId, Long memberId, IssueStatus status);
    List<IssueRecord> findByStatus(IssueStatus status);
    List<IssueRecord> findByMemberId(Long memberId);
    List<IssueRecord> findByBookId(Long bookId);
}
