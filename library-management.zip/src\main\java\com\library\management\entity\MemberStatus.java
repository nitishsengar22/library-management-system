package com.library.management.entity;

public enum MemberStatus {
    ACTIVE,
    INACTIVE
}
