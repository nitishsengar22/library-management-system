package com.library.management.controller;

import com.library.management.dto.IssueRequestDto;
import com.library.management.dto.IssueResponseDto;
import com.library.management.service.IssueService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/issues")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class IssueController {

    private final IssueService issueService;

    @PostMapping("/issue")
    public ResponseEntity<IssueResponseDto> issueBook(@Valid @RequestBody IssueRequestDto request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(issueService.issueBook(request));
    }

    @PostMapping("/return/{issueId}")
    public ResponseEntity<IssueResponseDto> returnBook(@PathVariable Long issueId) {
        return ResponseEntity.ok(issueService.returnBook(issueId));
    }

    @GetMapping("/active")
    public ResponseEntity<List<IssueResponseDto>> getActiveIssues() {
        return ResponseEntity.ok(issueService.getActiveIssues());
    }

    @GetMapping("/history/member/{memberId}")
    public ResponseEntity<List<IssueResponseDto>> getMemberHistory(@PathVariable Long memberId) {
        return ResponseEntity.ok(issueService.getMemberHistory(memberId));
    }

    @GetMapping("/history/book/{bookId}")
    public ResponseEntity<List<IssueResponseDto>> getBookHistory(@PathVariable Long bookId) {
        return ResponseEntity.ok(issueService.getBookHistory(bookId));
    }
}
