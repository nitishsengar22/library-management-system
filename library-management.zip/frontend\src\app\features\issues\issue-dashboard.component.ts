import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IssueService } from '../../core/services/issue.service';

@Component({
  selector: 'app-issue-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="container mt-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Library Issue/Return Dashboard</h2>
        <span class="badge bg-primary">Admin Portal</span>
      </div>
      
      <!-- Alert States -->
      <div *ngIf="errorMessage" class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error:</strong> {{ errorMessage }}
        <button type="button" class="btn-close" (click)="errorMessage = ''" aria-label="Close"></button>
      </div>
      <div *ngIf="successMessage" class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success:</strong> {{ successMessage }}
        <button type="button" class="btn-close" (click)="successMessage = ''" aria-label="Close"></button>
      </div>

      <div class="row">
        <!-- Issue Form Card -->
        <div class="col-lg-4 mb-4">
          <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white py-3">
              <h5 class="card-title mb-0"><i class="bi bi-book-half me-2"></i>Issue Book</h5>
            </div>
            <div class="card-body p-4">
              <form [formGroup]="issueForm" (ngSubmit)="onSubmit()">
                <div class="mb-3">
                  <label class="form-label font-weight-bold">Book ID</label>
                  <input type="number" formControlName="bookId" class="form-control" [class.is-invalid]="isInvalid('bookId')" placeholder="Enter Book ID">
                  <div class="invalid-feedback">Please enter a valid Book ID.</div>
                </div>
                
                <div class="mb-4">
                  <label class="form-label font-weight-bold">Member ID</label>
                  <input type="number" formControlName="memberId" class="form-control" [class.is-invalid]="isInvalid('memberId')" placeholder="Enter Member ID">
                  <div class="invalid-feedback">Please enter a valid Member ID.</div>
                </div>

                <button type="submit" class="btn btn-primary w-100 py-2 font-weight-bold" [disabled]="issueForm.invalid || isLoading">
                  <span *ngIf="isLoading" class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  {{ isLoading ? 'Processing...' : 'Issue Book' }}
                </button>
              </form>
            </div>
          </div>
        </div>

        <!-- Active Issues Table -->
        <div class="col-lg-8 mb-4">
          <div class="card shadow-sm border-0">
            <div class="card-header bg-dark text-white py-3 d-flex justify-content-between align-items-center">
              <h5 class="card-title mb-0"><i class="bi bi-journal-check me-2"></i>Active Issues</h5>
              <button class="btn btn-sm btn-outline-light" (click)="loadActiveIssues()" [disabled]="isLoading">
                <i class="bi bi-arrow-clockwise"></i> Refresh
              </button>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-striped table-hover mb-0 align-middle">
                  <thead class="table-light">
                    <tr>
                      <th class="ps-4">ID</th>
                      <th>Book</th>
                      <th>Member</th>
                      <th>Issued Date</th>
                      <th>Due Date</th>
                      <th class="pe-4 text-end">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let issue of activeIssues">
                      <td class="ps-4 font-monospace">{{ issue.id }}</td>
                      <td>
                        <div class="fw-bold">{{ issue.bookTitle }}</div>
                        <small class="text-muted">Book ID: {{ issue.bookId }}</small>
                      </td>
                      <td>
                        <div>{{ issue.memberName }}</div>
                        <small class="text-muted">Member ID: {{ issue.memberId }}</small>
                      </td>
                      <td>{{ issue.issuedAt | date:'mediumDate' }}</td>
                      <td>
                        <span class="badge" [ngClass]="isOverdue(issue.dueDate) ? 'bg-danger' : 'bg-warning text-dark'">
                          {{ issue.dueDate | date:'mediumDate' }}
                        </span>
                      </td>
                      <td class="pe-4 text-end">
                        <button class="btn btn-sm btn-success px-3" (click)="returnBook(issue.id)" [disabled]="isLoading">
                          Return Book
                        </button>
                      </td>
                    </tr>
                    <tr *ngIf="activeIssues.length === 0">
                      <td colspan="6" class="text-center py-4 text-muted">
                        <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                        No active issues found.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class IssueDashboardComponent implements OnInit {
  issueForm: FormGroup;
  activeIssues: any[] = [];
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  constructor(private fb: FormBuilder, private issueService: IssueService) {
    this.issueForm = this.fb.group({
      bookId: ['', [Validators.required, Validators.min(1)]],
      memberId: ['', [Validators.required, Validators.min(1)]]
    });
  }

  ngOnInit() {
    this.loadActiveIssues();
  }

  isInvalid(field: string): boolean {
    const ctrl = this.issueForm.get(field);
    return !!(ctrl && ctrl.invalid && (ctrl.dirty || ctrl.touched));
  }

  isOverdue(dueDateStr: string): boolean {
    const dueDate = new Date(dueDateStr);
    const today = new Date();
    // Reset times to compare dates only
    today.setHours(0, 0, 0, 0);
    dueDate.setHours(0, 0, 0, 0);
    return today > dueDate;
  }

  loadActiveIssues() {
    this.isLoading = true;
    this.issueService.getActiveIssues().subscribe({
      next: (res) => {
        try {
          this.activeIssues = res || [];
          this.isLoading = false;
        } catch (e) {
          console.error('Error processing active issues response:', e);
          this.isLoading = false;
        }
      },
      error: (err) => {
        console.error('Failed to load active issues:', err);
        this.errorMessage = 'Failed to load active issue records. Please verify if the backend server is running.';
        this.isLoading = false;
      }
    });
  }

  onSubmit() {
    if (this.issueForm.invalid) return;
    
    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.issueService.issueBook(this.issueForm.value).subscribe({
      next: (res) => {
        try {
          this.successMessage = `Book "${res?.bookTitle || 'Unknown'}" has been successfully issued to ${res?.memberName || 'Unknown Member'}!`;
          this.issueForm.reset();
          this.loadActiveIssues(); // Refresh table and reset isLoading
        } catch (e) {
          console.error('Error in issue book success handler:', e);
          this.isLoading = false;
        }
      },
      error: (err) => {
        console.error('Failed to issue book:', err);
        this.errorMessage = err.error?.message || err.message || 'An error occurred during the issue transaction. Please verify your connection.';
        this.isLoading = false;
      }
    });
  }

  returnBook(issueId: number) {
    if (!confirm('Are you sure you want to process return for this record?')) return;

    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.issueService.returnBook(issueId).subscribe({
      next: (res) => {
        try {
          this.successMessage = `Book "${res?.bookTitle || 'Unknown'}" returned successfully! Stock updated.`;
          this.loadActiveIssues(); // Refresh table and reset isLoading
        } catch (e) {
          console.error('Error in return book success handler:', e);
          this.isLoading = false;
        }
      },
      error: (err) => {
        console.error('Failed to return book:', err);
        this.errorMessage = err.error?.message || err.message || 'An error occurred during the return transaction.';
        this.isLoading = false;
      }
    });
  }
}
