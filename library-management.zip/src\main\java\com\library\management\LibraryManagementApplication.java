package com.library.management;

import com.library.management.entity.Book;
import com.library.management.entity.Member;
import com.library.management.entity.MemberStatus;
import com.library.management.repository.BookRepository;
import com.library.management.repository.MemberRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LibraryManagementApplication {
    public static void main(String[] eloquenceArgs) {
        SpringApplication.run(LibraryManagementApplication.class, eloquenceArgs);
    }

    @Bean
    public CommandLineRunner demoData(BookRepository bookRepo, MemberRepository memberRepo) {
        return args -> {
            if (bookRepo.count() == 0) {
                Book book1 = new Book();
                book1.setTitle("Clean Code");
                book1.setAuthor("Robert C. Martin");
                book1.setIsbn("9780132350884");
                book1.setTotalCopies(5);
                book1.setAvailableCopies(5);
                book1.setCategory("Programming");
                book1.setShelfLocation("A-12");
                bookRepo.save(book1);

                Book book2 = new Book();
                book2.setTitle("Design Patterns");
                book2.setAuthor("Erich Gamma");
                book2.setIsbn("9780201633610");
                book2.setTotalCopies(3);
                book2.setAvailableCopies(3);
                book2.setCategory("Software Architecture");
                book2.setShelfLocation("B-04");
                bookRepo.save(book2);
            }

            if (memberRepo.count() == 0) {
                Member member1 = new Member();
                member1.setName("John Doe");
                member1.setEmail("john.doe@example.com");
                member1.setStatus(MemberStatus.ACTIVE);
                memberRepo.save(member1);

                Member member2 = new Member();
                member2.setName("Jane Smith");
                member2.setEmail("jane.smith@example.com");
                member2.setStatus(MemberStatus.ACTIVE);
                memberRepo.save(member2);
            }
        };
    }
}
