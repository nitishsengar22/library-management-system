package com.library.management.service;

import com.library.management.dto.MemberCreateDto;
import com.library.management.dto.MemberDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface MemberService {
    Page<MemberDto> getAllMembers(Pageable pageable);
    MemberDto getMemberById(Long id);
    MemberDto createMember(MemberCreateDto dto);
    MemberDto updateMember(Long id, MemberCreateDto dto);
    MemberDto updateMemberStatus(Long id, String status);
}
