package com.library.management.service.impl;

import com.library.management.dto.IssueRequestDto;
import com.library.management.dto.IssueResponseDto;
import com.library.management.entity.*;
import com.library.management.exception.BusinessRuleException;
import com.library.management.exception.ResourceNotFoundException;
import com.library.management.repository.BookRepository;
import com.library.management.repository.IssueRecordRepository;
import com.library.management.repository.MemberRepository;
import com.library.management.service.IssueService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class IssueServiceImpl implements IssueService {

    private final IssueRecordRepository issueRepo;
    private final BookRepository bookRepo;
    private final MemberRepository memberRepo;

    @Override
    @Transactional
    public IssueResponseDto issueBook(IssueRequestDto request) {
        Book book = bookRepo.findById(request.getBookId())
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with ID: " + request.getBookId()));
        
        Member member = memberRepo.findById(request.getMemberId())
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with ID: " + request.getMemberId()));

        // Rule 1: Member must be active
        if (member.getStatus() != MemberStatus.ACTIVE) {
            throw new BusinessRuleException("Cannot issue book: Member is inactive.");
        }

        // Rule 2: Check available copies
        if (book.getAvailableCopies() <= 0) {
            throw new BusinessRuleException("Cannot issue book: No available copies.");
        }

        // Rule 3: Member cannot issue the same book twice without returning it
        boolean alreadyIssued = issueRepo.existsByBookIdAndMemberIdAndStatus(
                book.getId(), member.getId(), IssueStatus.ISSUED);
        if (alreadyIssued) {
            throw new BusinessRuleException("Member already has an active issue for this book.");
        }

        // Update Stock
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepo.save(book);

        // Create Record
        IssueRecord record = new IssueRecord();
        record.setBook(book);
        record.setMember(member);
        record.setIssuedAt(LocalDate.now());
        record.setDueDate(LocalDate.now().plusDays(14)); // Standard 14-day policy
        record.setStatus(IssueStatus.ISSUED);
        
        IssueRecord savedRecord = issueRepo.save(record);
        log.info("Book {} issued to Member {}", book.getId(), member.getId());
        
        return mapToDto(savedRecord);
    }

    @Override
    @Transactional
    public IssueResponseDto returnBook(Long issueId) {
        IssueRecord record = issueRepo.findById(issueId)
                .orElseThrow(() -> new ResourceNotFoundException("Issue record not found with ID: " + issueId));

        if (record.getStatus() == IssueStatus.RETURNED) {
            throw new BusinessRuleException("Book is already returned.");
        }

        // Update Record
        record.setReturnedAt(LocalDate.now());
        record.setStatus(IssueStatus.RETURNED);

        // Update Stock
        Book book = record.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepo.save(book);

        IssueRecord updatedRecord = issueRepo.save(record);
        log.info("Issue Record {} returned. Book stock incremented.", issueId);
        
        return mapToDto(updatedRecord);
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponseDto> getActiveIssues() {
        return issueRepo.findByStatus(IssueStatus.ISSUED).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponseDto> getMemberHistory(Long memberId) {
        return issueRepo.findByMemberId(memberId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<IssueResponseDto> getBookHistory(Long bookId) {
        return issueRepo.findByBookId(bookId).stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private IssueResponseDto mapToDto(IssueRecord record) {
        return IssueResponseDto.builder()
                .id(record.getId())
                .bookId(record.getBook().getId())
                .bookTitle(record.getBook().getTitle())
                .memberId(record.getMember().getId())
                .memberName(record.getMember().getName())
                .issuedAt(record.getIssuedAt())
                .dueDate(record.getDueDate())
                .returnedAt(record.getReturnedAt())
                .status(record.getStatus().name())
                .build();
    }
}
