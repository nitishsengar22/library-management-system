package com.library.management.service.impl;

import com.library.management.dto.MemberCreateDto;
import com.library.management.dto.MemberDto;
import com.library.management.entity.Member;
import com.library.management.entity.MemberStatus;
import com.library.management.exception.BusinessRuleException;
import com.library.management.exception.ResourceNotFoundException;
import com.library.management.repository.MemberRepository;
import com.library.management.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;

    @Override
    @Transactional(readOnly = true)
    public Page<MemberDto> getAllMembers(Pageable pageable) {
        return memberRepository.findAll(pageable).map(this::mapToDto);
    }

    @Override
    @Transactional(readOnly = true)
    public MemberDto getMemberById(Long id) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with ID: " + id));
        return mapToDto(member);
    }

    @Override
    @Transactional
    public MemberDto createMember(MemberCreateDto dto) {
        if (memberRepository.existsByEmail(dto.getEmail())) {
            throw new BusinessRuleException("Member with email " + dto.getEmail() + " already exists.");
        }
        Member member = new Member();
        member.setName(dto.getName());
        member.setEmail(dto.getEmail());
        member.setStatus(MemberStatus.ACTIVE); // default status is ACTIVE

        Member saved = memberRepository.save(member);
        return mapToDto(saved);
    }

    @Override
    @Transactional
    public MemberDto updateMember(Long id, MemberCreateDto dto) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with ID: " + id));

        if (!member.getEmail().equalsIgnoreCase(dto.getEmail()) && memberRepository.existsByEmail(dto.getEmail())) {
            throw new BusinessRuleException("Member with email " + dto.getEmail() + " already exists.");
        }

        member.setName(dto.getName());
        member.setEmail(dto.getEmail());

        Member updated = memberRepository.save(member);
        return mapToDto(updated);
    }

    @Override
    @Transactional
    public MemberDto updateMemberStatus(Long id, String status) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with ID: " + id));
        try {
            MemberStatus memberStatus = MemberStatus.valueOf(status.toUpperCase());
            member.setStatus(memberStatus);
        } catch (IllegalArgumentException e) {
            throw new BusinessRuleException("Invalid status: " + status + ". Allowed values: ACTIVE, INACTIVE");
        }
        Member updated = memberRepository.save(member);
        return mapToDto(updated);
    }

    private MemberDto mapToDto(Member member) {
        return MemberDto.builder()
                .id(member.getId())
                .name(member.getName())
                .email(member.getEmail())
                .status(member.getStatus().name())
                .createdAt(member.getCreatedAt())
                .build();
    }
}
