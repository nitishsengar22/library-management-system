import { Component, signal } from '@angular/core';
import { IssueDashboardComponent } from './features/issues/issue-dashboard.component';

@Component({
  selector: 'app-root',
  imports: [IssueDashboardComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('lms-frontend');
}
